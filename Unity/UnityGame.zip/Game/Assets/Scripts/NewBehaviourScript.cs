﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    public static HashSet<Collisions> registered = new HashSet<Collisions>();

        void Start()  
    {  

    }  
  
    // Update is called once per frame  
     void OnMouseDown(){
         string result="{[";
         foreach(Collisions collision in registered)
            result += collision.toString()+",";
        print(result+"]}");
     }
}
